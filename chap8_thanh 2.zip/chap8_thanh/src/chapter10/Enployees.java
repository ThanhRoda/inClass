package chapter10;

public class Enployees {
	private String Ename;
	private String ENumber;
	private String HireDate;
	
	
	public boolean EnumberChecking( String st) {
		return (Character.isDigit(st.charAt(0)) & Character.isDigit(st.charAt(1))
				&Character.isDigit(st.charAt(2)) & st.charAt(3) == '-' & 
						st.charAt(4) >= 'A' && st.charAt(4) <= 'M');
				
	}


	public Enployees(String ename, String eNumber, String hireDate) {
		super();
		Ename = ename;
		if(EnumberChecking(eNumber))
			ENumber = eNumber;
		else System.out.println("Invalaid Employee Numbers");
		HireDate = hireDate;
	}


	public String getEname() {
		return Ename;
	}


	public void setEname(String ename) {
		Ename = ename;
	}


	public String getENumber() {
		return ENumber;
	}


	public void setENumber(String eNumber) {
		if(EnumberChecking(eNumber))
			ENumber = eNumber;
		else System.out.println("Invalaid Employee Numbers");
	}


	public String getHireDate() {
		return HireDate;
	}


	public void setHireDate(String hireDate) {
		HireDate = hireDate;
	}


	@Override
	public String toString() {
		return "Enployees [Ename=" + Ename + ", ENumber=" + ENumber + ", HireDate=" + HireDate + "]";
	}
	
	
	
	
}
