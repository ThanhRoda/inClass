package chapter9;

import java.util.ArrayList;

public class Array {

	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<>();
		list.add(5);
		list.add(44);
		
	}

}
