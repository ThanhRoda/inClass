package chapter10;

public class InclassTest1 extends GradeActivity{
	private int NumberQ;
	private double ScoreEQ;
	private int NumberM;
	private double Score;
	
	public InclassTest1(int numberQ, int numberM ) {
		super();
		this.NumberQ = numberQ;
		this.NumberM = numberM;
		this.ScoreEQ = 100/ numberQ;
		this.Score= 100-(numberM*this.ScoreEQ);
		setScore(Score);
	}

	@Override
	public char getGrade() {
		return (getScore() > 50) ? 'P' : 'F' ;
		
	}

	
	
	

	
	
}
