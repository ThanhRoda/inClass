package chapter8;

public class Demo {

	public static void main(String[] args) {
		Rectangle react = new Rectangle(3,4);
		
		System.out.println(react.getLength());
		System.out.println(react.getWidth());
		System.out.println(react.getLength()* react.getWidth());
	}

}
