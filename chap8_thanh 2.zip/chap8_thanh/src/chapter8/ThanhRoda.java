package chapter8;

import java.util.Scanner;

public class ThanhRoda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter your name");
//		String name = sc.nextLine();
		char k = 't';
		if(Character.isDigit(k))
			System.out.println("Digit");
		else System.out.println(" no Digit");
		
		System.out.println(Character.toUpperCase(k));
		
		
		if(Character.isLetterOrDigit(k))
			System.out.println("Letter or number");
		else System.out.println(" no letter neither number");
		
		if(Character.isSpace(k))
			System.out.println("s");
		else System.out.println(" no Space");
			
//		System.out.println("Seer said that : whose name " + name +" is always handsome.");
//		System.out.println("Fist character : " +k);
		
//		sc.close();
		
	}

}
