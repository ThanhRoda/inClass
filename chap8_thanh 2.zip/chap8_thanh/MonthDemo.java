package enum_type;

public class MonthDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Month month1 = new Month("May");
		Month month2 = new Month("April");
		System.out.println(month1.getMonthNumber());
		System.out.println(month2.lessThan(month1));
		
	}

}
