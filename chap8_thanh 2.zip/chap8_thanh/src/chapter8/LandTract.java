package chapter8;

public class LandTract {
	private double w;
	private double l;
	
	public LandTract(double w, double l) {
		super();
		this.w = w;
		this.l = l;
	}
	
	public double getW() {
		return w;
	}

	public void setW(double w) {
		this.w = w;
	}

	public double getL() {
		return l;
	}

	public void setL(double l) {
		this.l = l;
	}

	public LandTract() {
		super();
		this.w = 0;
		this.l = 0;
	}

	public double getArea() {
		return this.l* this.w ;
	}
	public boolean equals(LandTract o) {
		return l == o.l && w == o.w ;
	}
	@Override
	public String toString() {
		return "LandTract [w=" + w + ", l=" + l + "]";
	}
	
}
