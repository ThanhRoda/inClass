package chapter8;
import java.util.concurrent.TimeUnit;

public class RectangleDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle rect = new Rectangle(3, 100);
		Rectangle rect1 = new Rectangle(3, 100);
		
				System.out.println(rect);
		if (rect.equals(rect1))
			System.out.println("Equal");
		else
			System.out.println("Not E");
			
		
				
	}

}
