package chapter10;

public class InclassDemo {

	public static void main(String[] args) {
		InclassTest1 s = new InclassTest1(20, 10);
		System.out.println(s.getScore() +" : "+ s.getGrade());
	}

}
