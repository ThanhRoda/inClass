package chapter10;

public class PassingScore extends GradeActivity{
	private double minimumPassingScore;

	public PassingScore(double minimumPassingScore) {
		super();
		this.minimumPassingScore = minimumPassingScore;
	}
	
	

	@Override
	public char getGrade() {
		// TODO Auto-generated method stub
		if(super.getScore()>= minimumPassingScore)
			return 'P';
		else 
			return 'F' ;
	}
	
	

}
