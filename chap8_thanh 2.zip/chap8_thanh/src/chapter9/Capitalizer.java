package chapter9;

public class Capitalizer {

	public static void main(String[] args) {
		getSentence("thanh.hekko.kkk");
		char a ='s';
		System.out.println(Character.toUpperCase(a));
		
	}
	public static String getSentence(String st) {
		StringBuilder s = new StringBuilder(st);
		s.setCharAt(0, Character.toUpperCase(s.charAt(0)));
		
		return s.toString();
		
	}
}
