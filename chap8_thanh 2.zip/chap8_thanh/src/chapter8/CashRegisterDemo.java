package chapter8;

public class CashRegisterDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		RetailItem re = new RetailItem();
		re.setPrice(2);
		CashRegister ca = new CashRegister(re, 100);
		
		System.out.println("Subtotal :" + ca.getSubtotal());
		System.out.println("Tax: " +ca.getTax());
		System.out.println("Total" +ca.getTotal());
	}

}
