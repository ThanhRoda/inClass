package chapter10;

public class ProductionWorker extends Enployees{
	private int shift;
	private double hPayRate;
	
	public ProductionWorker(String ename, String eNumber, String hireDate, int shift, double hPayRate) {
		super(ename, eNumber, hireDate);
		
		if (shiftChecking(shift))
			this.shift = shift;
		else System.out.println("Invalid shift");
		this.shift = shift;
		this.hPayRate = hPayRate;
	}
	public boolean shiftChecking(int shift) {
		if (shift !=1 & shift!=2 )
			return false;
		return true;
		
	}
	public int getShift() {
		return shift;
	}

	public void setShift(int shift) {
		if (shiftChecking(shift))
			this.shift = shift;
		else System.out.println("Invalid shift");
		
	}

	public double gethPayRate() {
		return hPayRate;
	}

	public void sethPayRate(double hPayRate) {
		this.hPayRate = hPayRate;
	}
	@Override
	public String toString() {
		return "ProductionWorker [shift=" + shift + ", hPayRate=" + hPayRate + ", getEname()=" + getEname()
				+ ", getENumber()=" + getENumber() + ", getHireDate()=" + getHireDate() + "]";
	}
	
	
	
	
}
