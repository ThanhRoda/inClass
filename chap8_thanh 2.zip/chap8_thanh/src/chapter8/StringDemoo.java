package chapter8;

public class StringDemoo {

	public static void main(String[] args) {
//		String s = "Hello boys";
//		String s1 = s.replaceAll("boys", "girls and boys");
//		System.out.println(s1);
//		
//		StringBuilder sb = new StringBuilder("thanh ro da");
//		sb.replace(5, 6, " to ");
//		System.out.println(sb);
		
		StringBuilder str = new StringBuilder(
                "I ate 100 blueberries!");
//Display the StringBuilder object.
System.out.println(str);
//Delete the '0'.
str.deleteCharAt(8);
//Delete "blue".
str.delete(9, 13);
//Display the StringBuilder object.
System.out.println(str);
//Change the '1' to '5'
str.setCharAt(6, '5');
//Display the StringBuilder object.
System.out.println(str);
		
		

	}

}
