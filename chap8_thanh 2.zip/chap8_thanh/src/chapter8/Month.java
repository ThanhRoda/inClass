package chapter8;

public class Month {
int monthNumber;
String monthName;
MonthName[] month = MonthName.values();

public Month() {
	monthNumber =1;
}

public Month(int monthNumber) {
	super();
	this.monthNumber = monthNumber;
	if (this.monthNumber > 12 || this.monthNumber <1)
		this.monthNumber =1;
}
public Month(String monthName) {
	
	for (int i=0; i<= 11; i++ ) {
		if (monthName.toUpperCase().compareTo(month[i].toString()) == 0) {
			this.monthNumber=i+1;
		break;
		}
	}
	
		
}
public String getMonthName() {
	this.monthName=month[this.monthNumber-1].toString();
	return this.monthName;
}

public int getMonthNumber() {
	return monthNumber;
}



}
