package chapter8;

public class PhoneDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "0323456789";		
		if(s.length()!=10 ) {
			System.out.println("It's not a phone number");
			return;
		}
		System.out.println(isNumber(s));
		if(isNumber(s)) {
			if (s.startsWith("09") || 	s.startsWith("09") ) {
				System.out.println("is phone");
			}
		}
			else System.out.println("It's not a phone number");										
	}
	public static boolean isNumber(String s) {
		for(int i=0; i<s.length() ; i++) {
			if (!Character.isDigit(i)) 
				return false;				
		}
		return true;		
	}

}
