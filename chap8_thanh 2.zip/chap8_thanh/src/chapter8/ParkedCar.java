package chapter8;

public class ParkedCar {

}
