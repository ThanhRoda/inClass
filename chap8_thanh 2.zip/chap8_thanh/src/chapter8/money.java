package chapter8;


public class money {
//private int VND;
//private double USD;
//
//public money(int vND) {
//	super();
//	VND = vND;
//}
//
//public int getVND() {
//	return VND;
//}
//
//public void setVND(int vND) {
//	VND = vND;
//}
//
//public  double convert() {
//	this.USD = this.VND / 25000;
//	return this.USD;
//}

public static double vndToDollar(double vnd)
{
	return vnd/25000;
}
}
