package chapter10;

public class PassfailExam extends PassingScore {
	private int NumberQ;
	private double ScoreEQ;
	private int NumberM;
	private double Score;
	
	public PassfailExam(double miniScore,int numberQ, int numberM ) {
		super(miniScore);
		this.NumberQ = numberQ;
		this.NumberM = numberM;
		this.ScoreEQ = 100/ numberQ;
		this.Score= 100-(numberM*this.ScoreEQ);
		setScore(Score);
	}
}
