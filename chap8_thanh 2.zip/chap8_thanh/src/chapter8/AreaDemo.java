package chapter8;

public class AreaDemo {

	public static void main(String[] args) {
		double circleArea = Area.getArea(5);
		double rectangleArea = Area.getArea(5, 10);
		double cylinderArea = Area.getArea(5.3, 10);
		
		System.out.printf("circle area : %.2f \n" , circleArea);
		System.out.println("rectangle area : " + rectangleArea);
		System.out.printf("cylinder area : %.2f" , cylinderArea);
	}

}
