package enum_type;

public enum MonthEnum {
	January, 
	February, 
	March, 
	April, 
	May,
	June, 
	July, 
	August, 
	September, 
	October,
	November, 
	December;
}
