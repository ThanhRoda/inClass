package chapter8;

import java.util.Scanner;

public class LandTractDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LandTract l1 = new LandTract(1,12);
		LandTract l2 = new LandTract(1,12);
		
//		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter w of l1");
//		l1.setW(sc.nextDouble());
//		System.out.println("Enter l of l1");
//		l1.setL(sc.nextDouble());
//		
//		System.out.println("Enter l of l2");
//		l2.setW(sc.nextDouble());
//		System.out.println("Enter l of l2");
//		l2.setL(sc.nextDouble());
		
		System.out.println("area land1 " + l1.getArea());
		System.out.println("area land2 " + l2.getArea());
		
		if (l1.equals(l2))
			System.out.println("E");
		else 
			System.out.println("Not E");
		System.out.println(l1);
		System.out.println(l2);
	}

}
