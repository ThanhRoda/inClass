package chapter8;

public class DemoMoney {

	public static void main(String[] args) {
		double usd = money.vndToDollar(50000);
		System.out.println(usd);

	}

}
