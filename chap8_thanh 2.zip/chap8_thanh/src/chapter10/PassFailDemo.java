package chapter10;

public class PassFailDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PassfailExam p = new PassfailExam(60, 10, 1);
		System.out.println( p.getGrade());
		

	}

}
