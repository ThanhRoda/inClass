package chapter10;

public class GradeActivity {
	private double score;

	public double getScore() {
		return score;
	}
	

	


	public void setScore(double score) {
		
		this.score = score;
	}
	public char getGrade() {
		char grade = '!';
		if(this.score >= 90)
			grade = 'A';
		else if(this.score >= 80)
			grade = 'B';
		else if(this.score >= 70)
			grade = 'C';
		else if(this.score >= 60)
			grade = 'D';
		else grade = 'F';
		return grade;
	}
}
