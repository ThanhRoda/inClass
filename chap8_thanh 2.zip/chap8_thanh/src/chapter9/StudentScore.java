package chapter9;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class StudentScore {

	public static void main(String[] args) throws IOException {
		ArrayList<String> list = new ArrayList<String>();
		File file = new File("StudentScore.txt");
		Scanner read = new Scanner(file);
		while (read.hasNext()) {
			list.add(read.nextLine());
		}
		int sum = 0;
		
		for (int i = 0; i <= list.size(); i++) {
			String sr = list.get(i);
			String[] temp = sr.split(": ");
			String[] Score = temp[1].split(",");
			double[] sc = new double[Score.length];
			System.out.println(Score.length);
			sum = 0;
			for (int j = 0; j < Score.length; j++) {
				sc[j] = Double.parseDouble(Score[j]);
				sum += sc[j];
			}
			System.out.println(temp[0] + " : " + (sum / Score.length));
			
		}

	}

}
