package chapter8;

public class Phone {
	private String s;

	public Phone(String s) {
		super();
		this.s = s;
	}
	public boolean isNumber() {
//		boolean flag = true;
		for(int i=0; i<this.s.length() ; i++) {
			if (Character.isLetter(i)) 
				return false;				
		}
		return true;		
	}
	public int getLength() {
		return this.s.length();
	}
	
	

}
