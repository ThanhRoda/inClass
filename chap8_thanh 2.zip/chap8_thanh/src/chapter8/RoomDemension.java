package chapter8;

public class RoomDemension {
private double l;
private double w;


public double getL() {
	return l;
}


public void setL(double l) {
	this.l = l;
}


public double getW() {
	return w;
}


public void setW(double w) {
	this.w = w;
}


public double getArea() {
	return l*w;
	
}


public RoomDemension(double l, double w) {
	super();
	this.l = l;
	this.w = w;
}
public RoomDemension(RoomDemension o2) {
	l= o2.l;
	w= o2.w;
}

}
