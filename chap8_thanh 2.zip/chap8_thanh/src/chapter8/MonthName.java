package chapter8;

public enum MonthName {
	JANUARY,
	FEBUARY,
	MARCH,
	APRIL,
	MAY,
	JUNE,
	JULY,
	AGUST,
	SEPTEMBER,
	OCTOBER,
	DECEMBER
}
