package chapter8;

public class Student {
 private String name ;
 private String ID;
public Student(String name, String iD) {
	super();
	this.name = name;
	ID = iD;
}
 

public Student(String name) {
	this(name, "01");
}


public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getID() {
	return ID;
}

public void setID(String iD) {
	ID = iD;
}

@Override
public String toString() {
	return "Student [name=" + name + ", ID=" + ID + "]";
}
 public boolean Equals(Student i) {
	 return name.equals(i.name) && ID.equals(i.ID);
 }
 public Student Coppy(Student i) {
	 Student coppy = new Student(i.name, i.ID);
	 return coppy;
			 
 }
}
