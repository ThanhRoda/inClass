package chapter8;

public enum Weekday {
	MONDAY,
	TUESDAY,
	WEDNESDAY,
	THURDAY,
	FRIDAY,
	SATURDAY,
	SUNDAY
	
}
