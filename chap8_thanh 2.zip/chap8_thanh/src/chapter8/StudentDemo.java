package chapter8;

public class StudentDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Student s1 = new Student("ThanhRoda", "23");
//		
//		Student s2 = new Student("ThanhRoda", "123");
//		Student s3 = s2 ;
//		System.out.println(s3);
//		s3.setID("1");
//		System.out.println();
////		
//		System.out.println(s3.Coppy(s1));
		
		Student st1 = new Student("thanh", "111");
				Student st2 = new Student("thanh");
				System.out.println(st1);	
				System.out.println(st2);
}
}
