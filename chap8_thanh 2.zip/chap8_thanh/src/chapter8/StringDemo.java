package chapter8;

public class StringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Four score and seven years ago";
		int first, last;
		first = str.indexOf('r');
		last = str.lastIndexOf('r');
		System.out.println("The letter r first appears at "
		                    + "position " + first);
		System.out.println("The letter r last appears at "
		                   + "position " + last);


		String str1 = "and a one and a two and a three";
		int position;
		System.out.println("The word and appears at the "
		                   + "following locations.");

		position = str1.indexOf("and");
		while (position != -1)
		{
		  System.out.println(position);
		  position = str1.indexOf("and", position + 1);
		}
	}

}
