package chapter8;

public class RoomCarpet {
private RoomDemension roomdemension;
private double cost;
public RoomCarpet(RoomDemension roomde, double cost) {
	super();
	roomdemension = new RoomDemension(roomde);
	this.cost = cost;
}
public double TotalAmount() {
	return this.roomdemension.getArea() * this.cost;
}


}
