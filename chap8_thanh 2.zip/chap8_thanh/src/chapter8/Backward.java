package chapter8;

public class Backward {

	public static void main(String[] args) {
		getBackward("Thanh Roda");
	}

	public static void getBackward(String s) {
		if (s==null) {
			System.out.println("this is null");
			return;
		}	
		for (int i = s.length()-1; i >= 0; i--) {
			System.out.print(s.charAt(i));
		}
	}
}
