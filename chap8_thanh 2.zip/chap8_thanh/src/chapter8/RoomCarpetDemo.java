package chapter8;

public class RoomCarpetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RoomDemension r1 = new RoomDemension(30, 50);
		RoomCarpet c1 = new RoomCarpet(r1, 15);
		r1.setL(2);
		
		System.out.println("Total cost : " + c1.TotalAmount());
	}

}
