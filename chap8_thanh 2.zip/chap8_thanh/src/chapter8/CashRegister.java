package chapter8;

public class CashRegister {
	private RetailItem retail;
	private int quantity;
	public CashRegister(RetailItem retail, int quantity) {
		super();
		this.retail = new RetailItem(retail);
		this.quantity = quantity;
	}
	public double getSubtotal() {
		return retail.getPrice()* quantity;
	}
	public double getTax() {
		return getSubtotal()*0.06;
	}
	public double getTotal() {
		return getSubtotal() + getTax();
	}
	
	

}
