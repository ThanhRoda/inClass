package chapter11111;

public class ParedCar {

}
