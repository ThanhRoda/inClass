package chapter8;

public class Area {

	public static double getArea(double r) {
		return r*r*Math.PI;
	}
	public static double getArea(int w, int l) {
		return w*l;
	}
	public static double getArea(double r, double h) {
		return r*r*Math.PI*h;
	}
}
