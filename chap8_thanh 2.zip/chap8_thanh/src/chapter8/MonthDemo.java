package chapter8;

public class MonthDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Month month = new Month("september");
		System.out.println(month.getMonthNumber());
		Month month1 = new Month(1);
		System.out.println(month1.getMonthName());
	}

}
