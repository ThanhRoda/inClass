package chapter10;

public class ShiftSupervisorDemo {

	public static void main(String[] args) {
		ShiftSupervisor demo =new ShiftSupervisor("Thanh", "123-A", "1/12/2010", 111, 2222);
		System.out.println(demo.toString());
	}

}
