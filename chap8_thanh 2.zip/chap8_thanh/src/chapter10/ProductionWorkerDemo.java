package chapter10;

public class ProductionWorkerDemo {

	public static void main(String[] args) {
		ProductionWorker demo= new ProductionWorker("Thanh", "123-A", "1/12/2010", 1, 2.25);
		System.out.println(demo.toString());
	}

}
