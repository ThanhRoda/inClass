package chapter10;

public class ShiftSupervisor extends Enployees{
	private  double anSalary;
	private  double  anProduction;
	
	public ShiftSupervisor(String ename, String eNumber, String hireDate, double anSalary, double anProduction) {
		super(ename, eNumber, hireDate);
		this.anSalary = anSalary;
		this.anProduction = anProduction;
	}

	@Override
	public String toString() {
		return "ShiftSupervisor [anSalary=" + anSalary + ", anProduction=" + anProduction + ", toString()="
				+ super.toString() + "]";
	}
	
	
}
