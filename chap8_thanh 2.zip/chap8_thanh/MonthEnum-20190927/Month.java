package enum_type;
public class Month {
	private int monthNumber;
	private MonthEnum[] monthEnums = 
			MonthEnum.values();
	
	public Month() {
		this.monthNumber = 1;
	}
	public Month(int monthNumber) {
		super();
		if(monthNumber < 1 || monthNumber >12)
			this.monthNumber = 1;
		else
			this.monthNumber = monthNumber;
		
	}
	public Month(String monthName)
	{	
		boolean valid = false;
		
		for(int i = 0; i < monthEnums.length; i++)
		{
			if(monthName.equals(monthEnums[i].toString()))
			{
				monthNumber = i+1;
				valid = true;
			}
				
		}
		if(valid == false)
		{
			monthNumber = 1;
		}
	}
	public int getMonthNumber() {
		return monthNumber;
	}
	public void setMonthNumber(int monthNumber) {
		if(monthNumber < 1 || monthNumber > 12)
			this.monthNumber = 1;
		else
			this.monthNumber = monthNumber;
	}
	public String getMonthName()
	{
		return monthEnums[monthNumber-1].toString();
	}
	public String toString()
	{
		return monthEnums[monthNumber-1].toString();
	}
	public boolean equals(Month another)
	{
		return monthNumber == another.monthNumber;
	}
	public boolean greaterThan(Month another)
	{
		return monthNumber > another.monthNumber;
	}
	public boolean lessThan(Month another)
	{
		return monthNumber < another.monthNumber;
	}
}
