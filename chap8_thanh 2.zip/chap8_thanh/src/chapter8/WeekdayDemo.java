package chapter8;

public class WeekdayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Weekday day= Weekday.FRIDAY ;
		Weekday day1= Weekday.SATURDAY ;
		System.out.println(day.compareTo(day1));
		System.out.println(day.ordinal() );
//		if (day == Weekday.WEDNESDAY) 
//			System.out.println("Woa amazing");
//		else System.out.println("oh no");
//		switch (day ) {
//		case FRIDAY: 
//			System.out.println("It is friday");
//			break;		
//		case WEDNESDAY:
//			System.out.println("wednesday");
//			break;
//		default:
//			System.out.println("It is not friday");
//			break;
//		}
		
//		for (int i =0; i< 3; i++) {
//			if (i == 0)
//				break;
//		}
		System.out.println(day.toString() );

	}

}
